<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Alunos</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: center; margin-top: 50px; }
        .container { width: 500px; }
        h2 { color: #6cb1dfff; text-align: center; font-weight: normal; margin-bottom: 25px; }
        
        /* Estrutura de cada linha do formulário */
        .form-group { display: flex; align-items: center; margin-bottom: 12px; }
        label { width: 140px; font-weight: bold; font-size: 18px; color: #333; }
        
        /* Estilo dos inputs */
        input, select { 
            padding: 8px; border: 1px solid #777; border-radius: 2px; font-size: 16px; flex: 1; 
        }
        
        /* Ajuste de largura para campos menores como na imagem */
        .w-small { max-width: 180px; }
        .placeholder-gray::placeholder { color: #aaa; }

        /* Botões */
        .btn-group { margin-left: 140px; margin-top: 20px; }
        button { 
            padding: 10px 30px; border: none; border-radius: 6px; color: white; 
            font-size: 18px; cursor: pointer; margin-right: 10px; 
        }
        .btn-inserir { background-color: #184f7cff; }
        .btn-fechar { background-color: #dd7571ff; }
    </style>
</head>
<body>

<div class="container">
    <h2>Cadastro de Alunos em PHP</h2>
    
    <form action="inserir.php" method="POST">
        <div class="form-group">
            <label>Nome:</label>
            <input type="text" name="nome">
        </div>

        <div class="form-group">
            <label>Municipio:</label>
            <select name="municipio">
                <option value=""></option>
                <option value="Sao Paulo">São Paulo</option>
                <option value="Rio de Janeiro">Rio de Janeiro</option>
            </select>
        </div>

        <div class="form-group">
            <label>Contato:</label>
            <input type="text" name="contato" id="contato" class="w-small placeholder-gray" placeholder="(00) 00000-0000">
        </div>

        <div class="form-group">
            <label>CPF:</label>
            <input type="text" name="cpf" id="cpf" class="w-small placeholder-gray" placeholder="000.000.000-00">
        </div>

        <div class="form-group">
            <label>RG:</label>
            <input type="text" name="rg" class="w-small">
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email">
        </div>

        <div class="form-group">
            <label>DtNascimento:</label>
            <input type="date" name="data_nascimento" class="w-small">
        </div>

        <div class="btn-group">
            <button type="submit" class="btn-inserir">Inserir</button>
            <button type="button" class="btn-fechar">Fechar</button>
        </div>
    </form>
</div>

<script>
    // Aplicando as máscaras nos campos específicos
    $(document).ready(function(){
        $('#contato').mask('(11) 9972-3534');
        $('#cpf').mask('999.000.025-72');
    });
</script>

</body>
</html>